/**
 * 
 */
/**
 * 
 */
module ajp_tx {
	requires java.sql;
	requires java.desktop;
}